﻿namespace csharp_exercise_login_2
{
    partial class frm_loading
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_loading));
            progressbar = new ProgressBar();
            pictureBox1 = new PictureBox();
            lblmessage = new Label();
            panel1 = new Panel();
            timer1 = new System.Windows.Forms.Timer(components);
            label1 = new Label();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // progressbar
            // 
            progressbar.Location = new Point(29, 503);
            progressbar.Name = "progressbar";
            progressbar.Size = new Size(1004, 29);
            progressbar.TabIndex = 0;
            progressbar.Click += progressBar1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(351, 53);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(366, 365);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // lblmessage
            // 
            lblmessage.AutoSize = true;
            lblmessage.Font = new Font("Yu Gothic UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblmessage.ForeColor = Color.Gainsboro;
            lblmessage.Location = new Point(29, 477);
            lblmessage.Name = "lblmessage";
            lblmessage.Size = new Size(100, 23);
            lblmessage.TabIndex = 14;
            lblmessage.Text = "Initializing...";
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateBlue;
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1066, 21);
            panel1.TabIndex = 15;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Yu Gothic UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.WhiteSmoke;
            label1.Location = new Point(284, 329);
            label1.Name = "label1";
            label1.Size = new Size(513, 54);
            label1.TabIndex = 16;
            label1.Text = "Simple Registration System";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Yu Gothic UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Gainsboro;
            label2.Location = new Point(693, 374);
            label2.Name = "label2";
            label2.Size = new Size(90, 23);
            label2.TabIndex = 17;
            label2.Text = "version 1.0";
            // 
            // frm_loading
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SlateBlue;
            ClientSize = new Size(1066, 558);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(panel1);
            Controls.Add(lblmessage);
            Controls.Add(pictureBox1);
            Controls.Add(progressbar);
            FormBorderStyle = FormBorderStyle.None;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "frm_loading";
            StartPosition = FormStartPosition.CenterScreen;
            Load += startup_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ProgressBar progressbar;
        private PictureBox pictureBox1;
        private Label lblmessage;
        private Panel panel1;
        private System.Windows.Forms.Timer timer1;
        private Label label1;
        private Label label2;
    }
}