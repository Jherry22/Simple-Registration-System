﻿using System.Data.OleDb;
using WinFormsApp1;

namespace csharp_exercise_login_2
{
    public partial class frm_admin : Form
    {
        private frm_loading frm_load;

        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\deleo\OneDrive\Documents\Desktop\db_final.mdb";
        string selectedUsername = string.Empty;
        string selectedPassword = string.Empty;
        int intAddEdit = 0;


        public string aaid { get; set; }

        public string aaname { get; set; }

        public frm_admin(frm_loading frmloadu)
        {
            InitializeComponent();
            aaid = frmloadu.AId;
            aaname = frmloadu.UNAME;
            label3.Text = aaname;
            Display();
            frm_load = frmloadu;
            for (double opacity = 0.0; opacity < 1.0; opacity += 0.1)
            {
                this.Opacity = opacity;
                System.Threading.Thread.Sleep(1);
            }

        }
        private void Display()
        {
            dgusers.Rows.Clear();
            InitializeDataGridView();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();

                    string strQuery = string.IsNullOrEmpty(txtsearch.Text)
                        ? "SELECT * FROM tbl_user WHERE priviledge = '2' AND manage = ?"
                        : "SELECT * FROM tbl_user WHERE priviledge = '2' AND manage = ? AND (" +
                          "fn LIKE ? OR " +
                          "ln LIKE ? OR " +
                          "[username] LIKE ? OR" +
                          "[password] LIKE ? OR" +
                          "[status] LIKE ?)";


                    using (OleDbCommand command = new OleDbCommand(strQuery, connection))
                    {
                        command.Parameters.AddWithValue("manage", aaid);

                        if (!string.IsNullOrEmpty(txtsearch.Text))
                        {
                            command.Parameters.AddWithValue("fn", "%" + txtsearch.Text.Trim() + "%");
                            command.Parameters.AddWithValue("ln", "%" + txtsearch.Text.Trim() + "%");
                            command.Parameters.AddWithValue("[username]", "%" + txtsearch.Text.Trim() + "%");
                            command.Parameters.AddWithValue("[password]", "%" + txtsearch.Text.Trim() + "%");
                            command.Parameters.AddWithValue("[status]", "%" + txtsearch.Text.Trim() + "%");
                        }

                        using (OleDbDataReader reader = command.ExecuteReader())
                        {
                            int no = 1;
                            while (reader.Read())
                            {
                                string statusText = reader["status"].ToString() == "1" ? "Active" : "Inactive";
                                dgusers.Rows.Add(no++, reader["fn"].ToString(), reader["ln"].ToString(), reader["username"].ToString(), reader["password"].ToString(), statusText);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }     

        private void InitializeDataGridView()
        {
            if (dgusers.Columns.Count == 0)
            {
                dgusers.Columns.Add("no", "No");
                dgusers.Columns.Add("fn", "Firstname");
                dgusers.Columns.Add("ln", "Lasname");
                dgusers.Columns.Add("username", "Username");
                dgusers.Columns.Add("password", "Password");
                dgusers.Columns.Add("status", "Status");
            }
        }

        private void ClearInputs()
        {
            txtsearch.Clear();
            txtfn.Clear();
            txtln.Clear();
            txtusername.Clear();
            txtpassword.Clear();
            cbostatus.SelectedIndex = -1;
        }

        private bool ValidateInputs()
        {
            bool isValid = true;

            if (string.IsNullOrWhiteSpace(txtfn.Text))
            {
                txtfn.Focus();
                isValid = false;
            }
            else if (string.IsNullOrWhiteSpace(txtln.Text))
            {
                txtln.Focus();
                isValid = false;
            }
            else if (string.IsNullOrWhiteSpace(txtusername.Text))
            {
                txtusername.Focus();
                isValid = false;
            }
            else if (string.IsNullOrWhiteSpace(txtpassword.Text))
            {
                txtpassword.Focus();
                isValid = false;
            }
            else if (cbostatus.SelectedIndex == -1)
            {
                cbostatus.Focus();
                isValid = false;
            }

            return isValid;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            if (ValidateInputs())
            {
                DialogResult result = MessageBox.Show("Are you sure you want to cancel the update?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    ClearInputs();
                    btninsert.Text = "Save";
                    addlabel.Text = "Add Record";
                    intAddEdit = 0;
                }
            }
        }

        private void dgadmin_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            Display();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            if (ValidateInputs())
            {
                DialogResult result = MessageBox.Show("Are you sure you want to cancel the update?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    ClearInputs();
                    btninsert.Text = "Save";
                    addlabel.Text = "Add Record";
                    intAddEdit = 0;
                }
            }
        }

        private void InsertRecord()
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();
                    using (OleDbCommand command = new OleDbCommand("INSERT INTO tbl_user (fn, ln, [username], [password], priviledge, [status], manage, a_id, date_created) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", connection))
                    {
                        command.Parameters.AddWithValue("fn", txtfn.Text.Trim());
                        command.Parameters.AddWithValue("ln", txtln.Text.Trim());
                        command.Parameters.AddWithValue("username", txtusername.Text.Trim());
                        command.Parameters.AddWithValue("password", txtpassword.Text.Trim());
                        command.Parameters.AddWithValue("priviledge", "2");
                        string status = cbostatus.SelectedItem != null && cbostatus.SelectedItem.ToString() == "Active" ? "1" : "0";
                        command.Parameters.AddWithValue("status", status);
                        command.Parameters.AddWithValue("manage", aaid);
                        command.Parameters.AddWithValue("a_id", "0");
                        DateTime value_date = DateTime.Now.Date;
                        command.Parameters.AddWithValue("date_created", value_date);
                        command.ExecuteNonQuery();
                        MessageBox.Show("Record has been saved.", "Insert Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void UpdateRecord()
        {
            if (selectedUsername != "")
            {
                try
                {
                    using (OleDbConnection connection = new OleDbConnection(connectionString))
                    {
                        connection.Open();
                        using (OleDbCommand command = new OleDbCommand(
                            "UPDATE tbl_user SET fn = ?, ln = ?, [username] = ?, [password] = ?, [status] = ? WHERE [username] = ? AND [password] = ?", connection))
                        {
                            command.Parameters.AddWithValue("fn", txtfn.Text.Trim());
                            command.Parameters.AddWithValue("ln", txtln.Text.Trim());
                            command.Parameters.AddWithValue("username", txtusername.Text.Trim());
                            command.Parameters.AddWithValue("password", txtpassword.Text.Trim());

                            string status = cbostatus.SelectedItem != null && cbostatus.SelectedItem.ToString() == "Active" ? "1" : "0";
                            command.Parameters.AddWithValue("status", status);

                            command.Parameters.AddWithValue("fn", selectedUsername);
                            command.Parameters.AddWithValue("password", selectedPassword);// Ensure this is correct
                            int rowsAffected = command.ExecuteNonQuery();
                            selectedUsername = "";
                            selectedPassword = "";
                            btninsert.Text = "Save";
                            addlabel.Text = "Add Account";

                            if (rowsAffected == 0)
                            {
                                MessageBox.Show("Update failed. No record was updated.", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                            else
                            {
                                MessageBox.Show("Record updated successfully.", "Update Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("No user is selected for update.", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        void DeleteRecord(string Username, string Password)
        {
            try
            {
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();
                    using (OleDbCommand command = new OleDbCommand("DELETE FROM tbl_user WHERE [username] = ? AND [password] = ?", connection))
                    {
                        command.Parameters.AddWithValue("username", Username);
                        command.Parameters.AddWithValue("password", Password);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            if (ValidateInputs())
            {
                if (intAddEdit == 1)
                {
                    UpdateRecord();
                    Display();
                    tabControl1.SelectedTab = tabControl1.TabPages["tabPage1"];
                    ClearInputs();
                    intAddEdit = 0;
                }
                else if (intAddEdit == 0)
                {
                    InsertRecord();
                    Display();
                    ClearInputs();
                    tabControl1.SelectedTab = tabControl1.TabPages["tabpage1"];
                }
            }
            else
            {
                MessageBox.Show("Please complete your credentials.");
            }
        }

        private void dgusers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (intAddEdit == 1)
            {
                if (ValidateInputs())
                {
                    DialogResult result_ = MessageBox.Show("Do you want to cancel the update?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result_ == DialogResult.Yes)
                    {
                        ClearInputs();
                        btninsert.Text = "Save";
                        addlabel.Text = "Add Record";
                        intAddEdit = 0;
                    }
                    else
                    {
                        tabControl1.SelectedTab = tabControl1.TabPages["tabpage2"];
                    }
                }
            }
            else
            {

                DialogResult result = MessageBox.Show("Do you want edit the record?", "Confirm Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    if (e.RowIndex >= 0)
                    {
                        DataGridViewRow row = dgusers.Rows[e.RowIndex];
                        selectedUsername = row.Cells["Column4"].Value?.ToString() ?? "NULL";
                        selectedPassword = row.Cells["Column5"].Value?.ToString() ?? "NULL";

                        txtfn.Text = row.Cells["Column2"].Value.ToString();
                        txtln.Text = row.Cells["Column3"].Value.ToString();
                        txtusername.Text = row.Cells["Column4"].Value.ToString();
                        txtpassword.Text = row.Cells["Column5"].Value.ToString();
                        cbostatus.SelectedItem = row.Cells["Column6"].Value.ToString() == "Active" ? "Active" : "Inactive";
                        intAddEdit = 1;
                        tabControl1.SelectedTab = tabControl1.TabPages["tabPage2"];
                        btninsert.Text = "Update";
                        addlabel.Text = "Update Record";
                    }

                }
            }
        }

        private void dgusers_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    InitializeDataGridView();
                    string Username = dgusers.Rows[e.RowIndex].Cells["Column4"].Value?.ToString() ?? "NULL";
                    string Password = dgusers.Rows[e.RowIndex].Cells["Column5"].Value?.ToString() ?? "NULL";
                    DeleteRecord(Username, Password);
                    Display();

                }

            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result_ = MessageBox.Show("Are you sure you want to logout??", "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result_ == DialogResult.Yes)
            {
                Application.Restart();
            }
              
        }
    }
}
