﻿


using System.Data.OleDb;
using csharp_exercise_login_2;

namespace WinFormsApp1
{
    public partial class frm_login : Form
    {
        private OleDbConnection conn;
        int ctr = 0;
        public string v_priv;
        public string a_id;
        public string a_u;
        public string f_u;
        public string l_u;

        public frm_login()
        {
            InitializeComponent();
            conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\deleo\OneDrive\Documents\Desktop\db_final.mdb");
            v_priv = string.Empty;
            a_id = string.Empty;
            a_u = string.Empty;
            f_u= string.Empty;      
            l_u = string.Empty;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            var txtuser = txtUsername.Text;
            var txtpass = txtpassword.Text;

            try
            {
                if (string.IsNullOrWhiteSpace(txtuser) || string.IsNullOrWhiteSpace(txtpass))
                {
                    if (string.IsNullOrWhiteSpace(txtuser))
                    {
                        txtUsername.Focus();
                    }

                    if (string.IsNullOrWhiteSpace(txtpass))
                    {
                        txtpassword.Focus();
                    }
                }
                else
                {
                    lbl_message.Visible = false;

                    using (OleDbConnection conn = new(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\deleo\OneDrive\Documents\Desktop\db_final.mdb"))
                    {
                        conn.Open();

                        string query = @"SELECT * FROM tbl_user WHERE username = @username AND password = @password";
                        using (OleDbCommand cmd = new(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@username", txtUsername.Text.Trim());
                            cmd.Parameters.AddWithValue("@password", txtpassword.Text.Trim());

                            using (OleDbDataReader dr = cmd.ExecuteReader())
                            {
                                if (dr.HasRows)
                                {
                                    dr.Read();
                                    if (dr["status"].ToString() != "1")
                                    {
                                        MessageBox.Show("Your account is inactive. Please contact the system administrator.");
                                        txtUsername.Clear();
                                        txtpassword.Clear();    
                                        return;
                                    }

                                    v_priv = dr["priviledge"]?.ToString() ?? "Unknown";
                                    a_id = dr["a_id"]?.ToString() ?? "0";
                                    a_u = dr["username"]?.ToString() ?? "Unknown";
                                    f_u =  dr["fn"]?.ToString() ?? "Unknown";
                                    l_u = dr["ln"]?.ToString() ?? "Unknown";

                                    MessageBox.Show("Successfully Login!");
                                    this.Hide();
                                    ctr = 0;

                                    frm_loading startUp = new(this);
                                    startUp.VPriv = v_priv;
                                    startUp.AId = a_id;
                                    startUp.UNAME = a_u;
                                    startUp.FUUU = f_u; 
                                    startUp.LUUU = l_u; 
                                    startUp.Show();

                                }
                                else
                                {
                                    ctr++;
                                    lbl_message.Visible = true;
                                    lbl_message.Text = "Wrong username or password. Try again.";
                                    txtUsername.Clear();
                                    txtpassword.Clear();
                                    txtUsername.Focus();
                                    txtpassword.Focus();

                                    if (ctr >= 3)
                                    {
                                        DeactivateAccount(txtuser);
                                        MessageBox.Show("You have committed 3 attempts of wrong password. Your account is now deactivated. Please contact the system administrator.");
                                        Application.Exit();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void DeactivateAccount(string username)
        {
            using (OleDbConnection conn = new(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\deleo\OneDrive\Documents\Desktop\db_final.mdb"))
            {
                conn.Open();
                string query = @"UPDATE tbl_user SET status = '0' WHERE username = @username";
                using (OleDbCommand cmd = new(query, conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            //
        }

        private void txtusername_TextChanged(object sender, EventArgs e)
        {
            if (txtUsername.Text != "")
            {
                lbl_message.Visible = false;
            }
        }

        private void txtpassword_TextChanged(object sender, EventArgs e)
        {
            if (txtpassword.Text != "")
            {
                lbl_message.Visible = false;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            //
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            //
        }
    }
}
