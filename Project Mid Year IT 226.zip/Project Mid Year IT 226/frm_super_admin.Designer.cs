﻿namespace csharp_exercise_login_2
{
    partial class frm_super_admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_super_admin));
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            dgusers = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            Column7 = new DataGridViewTextBoxColumn();
            btnsearch = new PictureBox();
            txtsearch = new TextBox();
            tabPage2 = new TabPage();
            panel2 = new Panel();
            txtid = new TextBox();
            cbostatus = new ComboBox();
            panel3 = new Panel();
            btncancel = new Button();
            txtusername = new TextBox();
            addlabel = new Label();
            txtln = new TextBox();
            btninsert = new Button();
            txtfn = new TextBox();
            txtpassword = new TextBox();
            label2 = new Label();
            pictureBox2 = new PictureBox();
            btnlogout = new Button();
            panel1 = new Panel();
            label3 = new Label();
            panel4 = new Panel();
            pictureBox1 = new PictureBox();
            btn_useraccounts = new Button();
            btn_adminaccounts = new Button();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgusers).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnsearch).BeginInit();
            tabPage2.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tabControl1.Location = new Point(346, 103);
            tabControl1.Margin = new Padding(4);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1099, 690);
            tabControl1.TabIndex = 14;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(dgusers);
            tabPage1.Controls.Add(btnsearch);
            tabPage1.Controls.Add(txtsearch);
            tabPage1.Location = new Point(4, 32);
            tabPage1.Margin = new Padding(4);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(4);
            tabPage1.Size = new Size(1091, 654);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "   Admin Accounts   ";
            tabPage1.UseVisualStyleBackColor = true;
            tabPage1.Click += tabPage1_Click;
            // 
            // dgusers
            // 
            dgusers.AllowUserToAddRows = false;
            dgusers.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = SystemColors.InactiveBorder;
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = Color.DodgerBlue;
            dataGridViewCellStyle1.SelectionForeColor = Color.White;
            dgusers.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dgusers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgusers.BackgroundColor = Color.White;
            dgusers.CellBorderStyle = DataGridViewCellBorderStyle.None;
            dgusers.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.Linen;
            dataGridViewCellStyle2.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = Color.Linen;
            dataGridViewCellStyle2.SelectionForeColor = Color.Black;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgusers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgusers.ColumnHeadersHeight = 40;
            dgusers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgusers.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5, Column6, Column7 });
            dgusers.EnableHeadersVisualStyles = false;
            dgusers.GridColor = Color.White;
            dgusers.Location = new Point(36, 100);
            dgusers.Margin = new Padding(4);
            dgusers.Name = "dgusers";
            dgusers.ReadOnly = true;
            dgusers.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = SystemColors.InactiveBorder;
            dataGridViewCellStyle3.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dgusers.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dgusers.RowHeadersWidth = 25;
            dgusers.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dgusers.ScrollBars = ScrollBars.Vertical;
            dgusers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgusers.Size = new Size(1022, 522);
            dgusers.TabIndex = 15;
            dgusers.CellContentClick += dgusers_CellContentClick;
            dgusers.CellDoubleClick += dgusers_CellDoubleClick;
            // 
            // Column1
            // 
            Column1.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column1.HeaderText = "No";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            Column1.Width = 60;
            // 
            // Column2
            // 
            Column2.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Column2.HeaderText = "First Name";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            // 
            // Column3
            // 
            Column3.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Column3.HeaderText = "Last Name";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            // 
            // Column4
            // 
            Column4.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Column4.HeaderText = "Username";
            Column4.MinimumWidth = 6;
            Column4.Name = "Column4";
            Column4.ReadOnly = true;
            // 
            // Column5
            // 
            Column5.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Column5.HeaderText = "Password";
            Column5.MinimumWidth = 6;
            Column5.Name = "Column5";
            Column5.ReadOnly = true;
            // 
            // Column6
            // 
            Column6.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Column6.HeaderText = "Status";
            Column6.MinimumWidth = 6;
            Column6.Name = "Column6";
            Column6.ReadOnly = true;
            // 
            // Column7
            // 
            Column7.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column7.HeaderText = "ID";
            Column7.MinimumWidth = 6;
            Column7.Name = "Column7";
            Column7.ReadOnly = true;
            Column7.Width = 54;
            // 
            // btnsearch
            // 
            btnsearch.Image = (Image)resources.GetObject("btnsearch.Image");
            btnsearch.Location = new Point(709, 41);
            btnsearch.Name = "btnsearch";
            btnsearch.Size = new Size(28, 28);
            btnsearch.TabIndex = 14;
            btnsearch.TabStop = false;
            // 
            // txtsearch
            // 
            txtsearch.Font = new Font("Yu Gothic UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtsearch.Location = new Point(743, 38);
            txtsearch.Margin = new Padding(4);
            txtsearch.Name = "txtsearch";
            txtsearch.PlaceholderText = " Search";
            txtsearch.Size = new Size(315, 31);
            txtsearch.TabIndex = 3;
            txtsearch.TextChanged += txtsearch_TextChanged_1;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(panel2);
            tabPage2.Location = new Point(4, 32);
            tabPage2.Margin = new Padding(4);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(4);
            tabPage2.Size = new Size(1091, 654);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "    Add Records     ";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(txtid);
            panel2.Controls.Add(cbostatus);
            panel2.Controls.Add(panel3);
            panel2.Controls.Add(btncancel);
            panel2.Controls.Add(txtusername);
            panel2.Controls.Add(addlabel);
            panel2.Controls.Add(txtln);
            panel2.Controls.Add(btninsert);
            panel2.Controls.Add(txtfn);
            panel2.Controls.Add(txtpassword);
            panel2.Location = new Point(335, 25);
            panel2.Name = "panel2";
            panel2.Size = new Size(514, 591);
            panel2.TabIndex = 10;
            // 
            // txtid
            // 
            txtid.BackColor = Color.Snow;
            txtid.Font = new Font("Yu Gothic UI", 10.2F);
            txtid.Location = new Point(105, 457);
            txtid.Margin = new Padding(4);
            txtid.Name = "txtid";
            txtid.PlaceholderText = " ID";
            txtid.Size = new Size(311, 30);
            txtid.TabIndex = 29;
            // 
            // cbostatus
            // 
            cbostatus.BackColor = Color.Snow;
            cbostatus.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cbostatus.ForeColor = Color.Gray;
            cbostatus.FormattingEnabled = true;
            cbostatus.Items.AddRange(new object[] { "Active", "Inactive" });
            cbostatus.Location = new Point(105, 399);
            cbostatus.Name = "cbostatus";
            cbostatus.Size = new Size(311, 31);
            cbostatus.TabIndex = 28;
            cbostatus.Text = " Status";
            // 
            // panel3
            // 
            panel3.BackColor = Color.MediumSlateBlue;
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(514, 38);
            panel3.TabIndex = 18;
            // 
            // btncancel
            // 
            btncancel.BackColor = Color.White;
            btncancel.Location = new Point(267, 513);
            btncancel.Margin = new Padding(4);
            btncancel.Name = "btncancel";
            btncancel.Size = new Size(94, 41);
            btncancel.TabIndex = 27;
            btncancel.Text = "Cancel";
            btncancel.UseVisualStyleBackColor = false;
            btncancel.Click += btncancel_Click;
            // 
            // txtusername
            // 
            txtusername.BackColor = Color.Snow;
            txtusername.Font = new Font("Yu Gothic UI", 10.2F);
            txtusername.Location = new Point(105, 269);
            txtusername.Margin = new Padding(4);
            txtusername.Name = "txtusername";
            txtusername.PlaceholderText = " Username";
            txtusername.Size = new Size(311, 30);
            txtusername.TabIndex = 24;
            // 
            // addlabel
            // 
            addlabel.AutoSize = true;
            addlabel.Location = new Point(191, 84);
            addlabel.Name = "addlabel";
            addlabel.Size = new Size(130, 23);
            addlabel.TabIndex = 23;
            addlabel.Text = "ADD ACCOUNT";
            // 
            // txtln
            // 
            txtln.BackColor = Color.Snow;
            txtln.Font = new Font("Yu Gothic UI", 10.2F);
            txtln.Location = new Point(105, 202);
            txtln.Margin = new Padding(4);
            txtln.Name = "txtln";
            txtln.PlaceholderText = " Last name";
            txtln.Size = new Size(311, 30);
            txtln.TabIndex = 22;
            // 
            // btninsert
            // 
            btninsert.BackColor = Color.White;
            btninsert.Location = new Point(369, 513);
            btninsert.Margin = new Padding(4);
            btninsert.Name = "btninsert";
            btninsert.Size = new Size(94, 41);
            btninsert.TabIndex = 26;
            btninsert.Text = "Insert";
            btninsert.UseVisualStyleBackColor = false;
            btninsert.Click += btninsert_Click_1;
            // 
            // txtfn
            // 
            txtfn.BackColor = Color.Snow;
            txtfn.Font = new Font("Yu Gothic UI", 10.2F);
            txtfn.Location = new Point(105, 133);
            txtfn.Margin = new Padding(4);
            txtfn.Name = "txtfn";
            txtfn.PlaceholderText = " First name";
            txtfn.Size = new Size(311, 30);
            txtfn.TabIndex = 21;
            // 
            // txtpassword
            // 
            txtpassword.BackColor = Color.Snow;
            txtpassword.Font = new Font("Yu Gothic UI", 10.2F);
            txtpassword.Location = new Point(105, 333);
            txtpassword.Margin = new Padding(4);
            txtpassword.Name = "txtpassword";
            txtpassword.PlaceholderText = " Password";
            txtpassword.Size = new Size(311, 30);
            txtpassword.TabIndex = 25;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Yu Gothic UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Image = (Image)resources.GetObject("label2.Image");
            label2.ImageAlign = ContentAlignment.BottomLeft;
            label2.Location = new Point(360, 40);
            label2.Name = "label2";
            label2.Size = new Size(522, 41);
            label2.TabIndex = 16;
            label2.Text = "    ADMIN ACCOUNT MANAGEMENT";
            label2.TextAlign = ContentAlignment.TopCenter;
            label2.ChangeUICues += label2_ChangeUICues;
            // 
            // pictureBox2
            // 
            pictureBox2.BackgroundImage = (Image)resources.GetObject("pictureBox2.BackgroundImage");
            pictureBox2.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox2.Location = new Point(1419, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(40, 38);
            pictureBox2.TabIndex = 17;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // btnlogout
            // 
            btnlogout.BackColor = Color.Transparent;
            btnlogout.FlatAppearance.BorderSize = 0;
            btnlogout.FlatStyle = FlatStyle.Flat;
            btnlogout.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnlogout.ForeColor = Color.White;
            btnlogout.Image = (Image)resources.GetObject("btnlogout.Image");
            btnlogout.ImageAlign = ContentAlignment.MiddleLeft;
            btnlogout.Location = new Point(0, 739);
            btnlogout.Margin = new Padding(4);
            btnlogout.Name = "btnlogout";
            btnlogout.Padding = new Padding(25, 0, 0, 0);
            btnlogout.Size = new Size(312, 46);
            btnlogout.TabIndex = 5;
            btnlogout.Text = "         Logout";
            btnlogout.TextAlign = ContentAlignment.MiddleLeft;
            btnlogout.UseVisualStyleBackColor = false;
            btnlogout.Click += btnlogout_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateBlue;
            panel1.Controls.Add(label3);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(btn_useraccounts);
            panel1.Controls.Add(btn_adminaccounts);
            panel1.Controls.Add(btnlogout);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4);
            panel1.Name = "panel1";
            panel1.Size = new Size(312, 806);
            panel1.TabIndex = 15;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Yu Gothic UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(68, 198);
            label3.Name = "label3";
            label3.Size = new Size(160, 23);
            label3.TabIndex = 13;
            label3.Text = "S_Admin_Username";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            label3.Click += label3_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.White;
            panel4.Location = new Point(34, 243);
            panel4.Name = "panel4";
            panel4.Size = new Size(250, 1);
            panel4.TabIndex = 9;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(83, 44);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(139, 143);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // btn_useraccounts
            // 
            btn_useraccounts.BackColor = Color.Transparent;
            btn_useraccounts.FlatAppearance.BorderSize = 0;
            btn_useraccounts.FlatStyle = FlatStyle.Flat;
            btn_useraccounts.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_useraccounts.ForeColor = Color.White;
            btn_useraccounts.Image = (Image)resources.GetObject("btn_useraccounts.Image");
            btn_useraccounts.ImageAlign = ContentAlignment.MiddleLeft;
            btn_useraccounts.Location = new Point(0, 277);
            btn_useraccounts.Margin = new Padding(4);
            btn_useraccounts.Name = "btn_useraccounts";
            btn_useraccounts.Padding = new Padding(55, 0, 0, 0);
            btn_useraccounts.Size = new Size(312, 46);
            btn_useraccounts.TabIndex = 7;
            btn_useraccounts.Text = "         User Accounts";
            btn_useraccounts.TextAlign = ContentAlignment.MiddleLeft;
            btn_useraccounts.UseVisualStyleBackColor = false;
            btn_useraccounts.Click += btn_useraccounts_Click;
            // 
            // btn_adminaccounts
            // 
            btn_adminaccounts.BackColor = Color.Transparent;
            btn_adminaccounts.FlatAppearance.BorderSize = 0;
            btn_adminaccounts.FlatStyle = FlatStyle.Flat;
            btn_adminaccounts.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_adminaccounts.ForeColor = Color.White;
            btn_adminaccounts.Image = (Image)resources.GetObject("btn_adminaccounts.Image");
            btn_adminaccounts.ImageAlign = ContentAlignment.MiddleLeft;
            btn_adminaccounts.Location = new Point(0, 331);
            btn_adminaccounts.Margin = new Padding(4);
            btn_adminaccounts.Name = "btn_adminaccounts";
            btn_adminaccounts.Padding = new Padding(55, 0, 0, 0);
            btn_adminaccounts.Size = new Size(312, 46);
            btn_adminaccounts.TabIndex = 6;
            btn_adminaccounts.Text = "         Admin Accounts";
            btn_adminaccounts.TextAlign = ContentAlignment.MiddleLeft;
            btn_adminaccounts.UseVisualStyleBackColor = false;
            // 
            // frm_super_admin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1473, 806);
            Controls.Add(pictureBox2);
            Controls.Add(label2);
            Controls.Add(panel1);
            Controls.Add(tabControl1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frm_super_admin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "    Super Admin Page";
            Load += frm_super_admin_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgusers).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnsearch).EndInit();
            tabPage2.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private PictureBox btnsearch;
        private TextBox txtsearch;
        private TabPage tabPage2;
        private Label label2;
        private PictureBox pictureBox2;
        private Button btnlogout;
        private Panel panel1;
        private Label label3;
        private Panel panel4;
        private PictureBox pictureBox1;
        private Button btn_useraccounts;
        private Button btn_adminaccounts;
        private Panel panel2;
        private Panel panel3;
        private DataGridView dgusers;
        private ComboBox cbostatus;
        private Button btncancel;
        private TextBox txtusername;
        private Label addlabel;
        private TextBox txtln;
        private Button btninsert;
        private TextBox txtfn;
        private TextBox txtpassword;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private DataGridViewTextBoxColumn Column7;
        private TextBox txtid;
    }
}