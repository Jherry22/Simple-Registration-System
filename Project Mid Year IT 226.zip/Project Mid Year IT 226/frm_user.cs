﻿using csharp_exercise_login_2;

namespace WinFormsApp1
{
    public partial class frm_user : Form
    {
        private frm_loading frm_load_u;

        public string uuu_ { get; set; }

        public string fff_ { get; set; }

        public string lll_ { get; set; }

        public frm_user(frm_loading frm_loadu)
        {
            InitializeComponent();

            uuu_ = frm_loadu.UNAME;
            label1.Text = uuu_;
            label2.Text = "      "+uuu_;

            fff_ = frm_loadu.FUUU;
            lll_ = frm_loadu.LUUU;
            lblu.Text = fff_ + " " + lll_;

            frm_load_u = frm_loadu;

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            DialogResult result_ = MessageBox.Show("Are you sure you want to logout??", "Confirm Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result_ == DialogResult.Yes)
            {
                Application.Restart();
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void lblu_Click(object sender, EventArgs e)
        {

        }
    }
}
