﻿namespace csharp_exercise_login_2
{
    partial class adminPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(adminPage));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            panel1 = new Panel();
            label3 = new Label();
            panel4 = new Panel();
            pictureBox1 = new PictureBox();
            btn_useraccounts = new Button();
            btn_adminaccounts = new Button();
            btnlogout = new Button();
            label2 = new Label();
            pictureBox2 = new PictureBox();
            tabPage2 = new TabPage();
            panel2 = new Panel();
            txtmanager = new TextBox();
            cbostatus = new ComboBox();
            btncancel = new Button();
            panel3 = new Panel();
            addlabel = new Label();
            btninsert = new Button();
            txtpassword = new TextBox();
            txtusername = new TextBox();
            txtfn = new TextBox();
            txtln = new TextBox();
            tabPage1 = new TabPage();
            btnsearch = new PictureBox();
            dgusers = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            Column7 = new DataGridViewTextBoxColumn();
            txtsearch = new TextBox();
            tabControl1 = new TabControl();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            tabPage2.SuspendLayout();
            panel2.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btnsearch).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgusers).BeginInit();
            tabControl1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateBlue;
            panel1.Controls.Add(label3);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(btn_useraccounts);
            panel1.Controls.Add(btn_adminaccounts);
            panel1.Controls.Add(btnlogout);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4);
            panel1.Name = "panel1";
            panel1.Size = new Size(312, 806);
            panel1.TabIndex = 7;
            panel1.Paint += panel1_Paint;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Yu Gothic UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(70, 198);
            label3.Name = "label3";
            label3.Size = new Size(160, 23);
            label3.TabIndex = 13;
            label3.Text = "S_Admin_Username";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            panel4.BackColor = Color.White;
            panel4.Location = new Point(34, 243);
            panel4.Name = "panel4";
            panel4.Size = new Size(250, 1);
            panel4.TabIndex = 9;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(83, 44);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(139, 143);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // btn_useraccounts
            // 
            btn_useraccounts.BackColor = Color.Transparent;
            btn_useraccounts.FlatAppearance.BorderSize = 0;
            btn_useraccounts.FlatStyle = FlatStyle.Flat;
            btn_useraccounts.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_useraccounts.ForeColor = Color.White;
            btn_useraccounts.Image = (Image)resources.GetObject("btn_useraccounts.Image");
            btn_useraccounts.ImageAlign = ContentAlignment.MiddleLeft;
            btn_useraccounts.Location = new Point(0, 277);
            btn_useraccounts.Margin = new Padding(4);
            btn_useraccounts.Name = "btn_useraccounts";
            btn_useraccounts.Padding = new Padding(55, 0, 0, 0);
            btn_useraccounts.Size = new Size(312, 46);
            btn_useraccounts.TabIndex = 7;
            btn_useraccounts.Text = "         User Accounts";
            btn_useraccounts.TextAlign = ContentAlignment.MiddleLeft;
            btn_useraccounts.UseVisualStyleBackColor = false;
            // 
            // btn_adminaccounts
            // 
            btn_adminaccounts.BackColor = Color.Transparent;
            btn_adminaccounts.FlatAppearance.BorderSize = 0;
            btn_adminaccounts.FlatStyle = FlatStyle.Flat;
            btn_adminaccounts.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_adminaccounts.ForeColor = Color.White;
            btn_adminaccounts.Image = (Image)resources.GetObject("btn_adminaccounts.Image");
            btn_adminaccounts.ImageAlign = ContentAlignment.MiddleLeft;
            btn_adminaccounts.Location = new Point(0, 331);
            btn_adminaccounts.Margin = new Padding(4);
            btn_adminaccounts.Name = "btn_adminaccounts";
            btn_adminaccounts.Padding = new Padding(55, 0, 0, 0);
            btn_adminaccounts.Size = new Size(312, 46);
            btn_adminaccounts.TabIndex = 6;
            btn_adminaccounts.Text = "         Admin Accounts";
            btn_adminaccounts.TextAlign = ContentAlignment.MiddleLeft;
            btn_adminaccounts.UseVisualStyleBackColor = false;
            btn_adminaccounts.Click += btn_adminaccounts_Click;
            // 
            // btnlogout
            // 
            btnlogout.BackColor = Color.Transparent;
            btnlogout.FlatAppearance.BorderSize = 0;
            btnlogout.FlatStyle = FlatStyle.Flat;
            btnlogout.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnlogout.ForeColor = Color.White;
            btnlogout.Image = (Image)resources.GetObject("btnlogout.Image");
            btnlogout.ImageAlign = ContentAlignment.MiddleLeft;
            btnlogout.Location = new Point(0, 739);
            btnlogout.Margin = new Padding(4);
            btnlogout.Name = "btnlogout";
            btnlogout.Padding = new Padding(25, 0, 0, 0);
            btnlogout.Size = new Size(312, 46);
            btnlogout.TabIndex = 5;
            btnlogout.Text = "         Logout";
            btnlogout.TextAlign = ContentAlignment.MiddleLeft;
            btnlogout.UseVisualStyleBackColor = false;
            btnlogout.Click += btnlogout_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Yu Gothic UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Image = (Image)resources.GetObject("label2.Image");
            label2.ImageAlign = ContentAlignment.BottomLeft;
            label2.Location = new Point(346, 40);
            label2.Name = "label2";
            label2.Size = new Size(492, 41);
            label2.TabIndex = 13;
            label2.Text = "    USER ACCOUNT MANAGEMENT";
            // 
            // pictureBox2
            // 
            pictureBox2.BackgroundImage = (Image)resources.GetObject("pictureBox2.BackgroundImage");
            pictureBox2.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox2.Location = new Point(1419, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(40, 38);
            pictureBox2.TabIndex = 18;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(panel2);
            tabPage2.Location = new Point(4, 32);
            tabPage2.Margin = new Padding(4);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(4);
            tabPage2.Size = new Size(1091, 654);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "    Add Records     ";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(txtmanager);
            panel2.Controls.Add(cbostatus);
            panel2.Controls.Add(btncancel);
            panel2.Controls.Add(panel3);
            panel2.Controls.Add(addlabel);
            panel2.Controls.Add(btninsert);
            panel2.Controls.Add(txtpassword);
            panel2.Controls.Add(txtusername);
            panel2.Controls.Add(txtfn);
            panel2.Controls.Add(txtln);
            panel2.Location = new Point(335, 25);
            panel2.Name = "panel2";
            panel2.Size = new Size(514, 591);
            panel2.TabIndex = 10;
            panel2.Paint += panel2_Paint;
            // 
            // txtmanager
            // 
            txtmanager.BackColor = Color.Snow;
            txtmanager.Font = new Font("Yu Gothic UI", 10.2F);
            txtmanager.Location = new Point(106, 460);
            txtmanager.Margin = new Padding(4);
            txtmanager.Name = "txtmanager";
            txtmanager.PlaceholderText = " Manager";
            txtmanager.Size = new Size(311, 30);
            txtmanager.TabIndex = 21;
            // 
            // cbostatus
            // 
            cbostatus.BackColor = Color.Snow;
            cbostatus.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cbostatus.ForeColor = Color.Gray;
            cbostatus.FormattingEnabled = true;
            cbostatus.Items.AddRange(new object[] { "Active", "Inactive" });
            cbostatus.Location = new Point(106, 401);
            cbostatus.Name = "cbostatus";
            cbostatus.Size = new Size(311, 31);
            cbostatus.TabIndex = 20;
            cbostatus.Text = " Status";
            // 
            // btncancel
            // 
            btncancel.BackColor = Color.White;
            btncancel.Location = new Point(267, 519);
            btncancel.Margin = new Padding(4);
            btncancel.Name = "btncancel";
            btncancel.Size = new Size(94, 41);
            btncancel.TabIndex = 19;
            btncancel.Text = "Cancel";
            btncancel.UseVisualStyleBackColor = false;
            btncancel.Click += button1_Click_1;
            // 
            // panel3
            // 
            panel3.BackColor = Color.MediumSlateBlue;
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(514, 38);
            panel3.TabIndex = 18;
            panel3.Paint += panel3_Paint;
            // 
            // addlabel
            // 
            addlabel.AutoSize = true;
            addlabel.Location = new Point(191, 90);
            addlabel.Name = "addlabel";
            addlabel.Size = new Size(130, 23);
            addlabel.TabIndex = 12;
            addlabel.Text = "ADD ACCOUNT";
            // 
            // btninsert
            // 
            btninsert.BackColor = Color.White;
            btninsert.Location = new Point(369, 519);
            btninsert.Margin = new Padding(4);
            btninsert.Name = "btninsert";
            btninsert.Size = new Size(94, 41);
            btninsert.TabIndex = 17;
            btninsert.Text = "Insert";
            btninsert.UseVisualStyleBackColor = false;
            btninsert.Click += btninsert_Click;
            // 
            // txtpassword
            // 
            txtpassword.BackColor = Color.Snow;
            txtpassword.Font = new Font("Yu Gothic UI", 10.2F);
            txtpassword.Location = new Point(106, 337);
            txtpassword.Margin = new Padding(4);
            txtpassword.Name = "txtpassword";
            txtpassword.PlaceholderText = " Password";
            txtpassword.Size = new Size(311, 30);
            txtpassword.TabIndex = 13;
            // 
            // txtusername
            // 
            txtusername.BackColor = Color.Snow;
            txtusername.Font = new Font("Yu Gothic UI", 10.2F);
            txtusername.Location = new Point(106, 273);
            txtusername.Margin = new Padding(4);
            txtusername.Name = "txtusername";
            txtusername.PlaceholderText = " Username";
            txtusername.Size = new Size(311, 30);
            txtusername.TabIndex = 12;
            // 
            // txtfn
            // 
            txtfn.BackColor = Color.Snow;
            txtfn.Font = new Font("Yu Gothic UI", 10.2F);
            txtfn.Location = new Point(106, 137);
            txtfn.Margin = new Padding(4);
            txtfn.Name = "txtfn";
            txtfn.PlaceholderText = " First name";
            txtfn.Size = new Size(311, 30);
            txtfn.TabIndex = 8;
            // 
            // txtln
            // 
            txtln.BackColor = Color.Snow;
            txtln.Font = new Font("Yu Gothic UI", 10.2F);
            txtln.Location = new Point(106, 206);
            txtln.Margin = new Padding(4);
            txtln.Name = "txtln";
            txtln.PlaceholderText = " Last name";
            txtln.Size = new Size(311, 30);
            txtln.TabIndex = 9;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(btnsearch);
            tabPage1.Controls.Add(dgusers);
            tabPage1.Controls.Add(txtsearch);
            tabPage1.Location = new Point(4, 32);
            tabPage1.Margin = new Padding(4);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(4);
            tabPage1.Size = new Size(1091, 654);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "   Admin Accounts   ";
            tabPage1.UseVisualStyleBackColor = true;
            tabPage1.Click += tabPage1_Click;
            // 
            // btnsearch
            // 
            btnsearch.Image = (Image)resources.GetObject("btnsearch.Image");
            btnsearch.Location = new Point(708, 48);
            btnsearch.Name = "btnsearch";
            btnsearch.Size = new Size(28, 28);
            btnsearch.TabIndex = 14;
            btnsearch.TabStop = false;
            // 
            // dgusers
            // 
            dgusers.AllowUserToAddRows = false;
            dgusers.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = SystemColors.InactiveBorder;
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = Color.DodgerBlue;
            dataGridViewCellStyle1.SelectionForeColor = Color.White;
            dgusers.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dgusers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgusers.BackgroundColor = Color.White;
            dgusers.CellBorderStyle = DataGridViewCellBorderStyle.None;
            dgusers.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.Linen;
            dataGridViewCellStyle2.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = Color.Linen;
            dataGridViewCellStyle2.SelectionForeColor = Color.Black;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgusers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgusers.ColumnHeadersHeight = 40;
            dgusers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgusers.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5, Column6, Column7 });
            dgusers.EnableHeadersVisualStyles = false;
            dgusers.GridColor = Color.White;
            dgusers.Location = new Point(36, 100);
            dgusers.Margin = new Padding(4);
            dgusers.Name = "dgusers";
            dgusers.ReadOnly = true;
            dgusers.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = SystemColors.InactiveBorder;
            dataGridViewCellStyle3.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dgusers.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dgusers.RowHeadersWidth = 25;
            dgusers.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dgusers.ScrollBars = ScrollBars.Vertical;
            dgusers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgusers.Size = new Size(1022, 522);
            dgusers.TabIndex = 0;
            dgusers.CellContentClick += dgusers_CellContentClick;
            dgusers.CellDoubleClick += dgusers_CellDoubleClick;
            // 
            // Column1
            // 
            Column1.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column1.HeaderText = "No";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            Column1.Width = 60;
            // 
            // Column2
            // 
            Column2.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Column2.HeaderText = "First Name";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            // 
            // Column3
            // 
            Column3.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Column3.HeaderText = "Last Name";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            // 
            // Column4
            // 
            Column4.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Column4.HeaderText = "Username";
            Column4.MinimumWidth = 6;
            Column4.Name = "Column4";
            Column4.ReadOnly = true;
            // 
            // Column5
            // 
            Column5.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Column5.HeaderText = "Password";
            Column5.MinimumWidth = 6;
            Column5.Name = "Column5";
            Column5.ReadOnly = true;
            // 
            // Column6
            // 
            Column6.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column6.HeaderText = "Status";
            Column6.MinimumWidth = 6;
            Column6.Name = "Column6";
            Column6.ReadOnly = true;
            Column6.Width = 84;
            // 
            // Column7
            // 
            Column7.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column7.HeaderText = "Manager";
            Column7.MinimumWidth = 6;
            Column7.Name = "Column7";
            Column7.ReadOnly = true;
            Column7.Width = 106;
            // 
            // txtsearch
            // 
            txtsearch.Font = new Font("Yu Gothic UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtsearch.Location = new Point(742, 45);
            txtsearch.Margin = new Padding(4);
            txtsearch.Name = "txtsearch";
            txtsearch.PlaceholderText = " Search";
            txtsearch.Size = new Size(316, 31);
            txtsearch.TabIndex = 3;
            txtsearch.TextChanged += txtsearch_TextChanged;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tabControl1.Location = new Point(346, 103);
            tabControl1.Margin = new Padding(4);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1099, 690);
            tabControl1.TabIndex = 6;
            // 
            // adminPage
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1473, 806);
            Controls.Add(pictureBox2);
            Controls.Add(label2);
            Controls.Add(panel1);
            Controls.Add(tabControl1);
            Font = new Font("Yu Gothic UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4);
            MaximizeBox = false;
            Name = "adminPage";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "    Super Admin Page";
            Load += adminPage_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            tabPage2.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)btnsearch).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgusers).EndInit();
            tabControl1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel panel1;
        private Button btnlogout;
        private Label label2;
        private Button btn_useraccounts;
        private Button btn_adminaccounts;
        private PictureBox pictureBox1;
        private Panel panel4;
        private Label label3;
        private PictureBox pictureBox2;
        private TabPage tabPage2;
        private Panel panel2;
        private ComboBox cbostatus;
        private Button btncancel;
        private Panel panel3;
        private Label addlabel;
        private Button btninsert;
        private TextBox txtpassword;
        private TextBox txtusername;
        private TextBox txtfn;
        private TextBox txtln;
        private TabPage tabPage1;
        private PictureBox btnsearch;
        private DataGridView dgusers;
        private TextBox txtsearch;
        private TabControl tabControl1;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private DataGridViewTextBoxColumn Column7;
        private TextBox txtmanager;
    }
}