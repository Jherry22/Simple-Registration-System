﻿using WinFormsApp1;

namespace csharp_exercise_login_2
{
    public partial class frm_loading : Form
    {
        private frm_login frm_login_sub;
        public string VPriv { get; set; }

        public string AId { get; set; }

        public string UNAME { get; set; }

        public string FUUU { get; set; }

        public string LUUU { get; set; }



#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
        public frm_loading(frm_login frm_loginsub)
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
        {
            InitializeComponent();
            frm_login_sub = frm_loginsub;
        }

        private void startup_Load(object sender, EventArgs e)
        {
            timer1.Start();
            progressbar.Value = 0;
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {
            // Handle click event if needed
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressbar.Value < 100)
            {
                if (progressbar.Value <= 10)
                {
                    lblmessage.Text = progressbar.Value + "% Loading...";
                }
                else if (progressbar.Value == 30)
                {
                    lblmessage.Text = progressbar.Value + "% Preparing System...";
                }
                else if (progressbar.Value == 50)
                {
                    lblmessage.Text = progressbar.Value + "% Please be patient...";
                }
                else if (progressbar.Value == 80)
                {
                    lblmessage.Text = progressbar.Value + "% Nice! We're Ready...";
                }
                else
                {
                    lblmessage.Text = progressbar.Value + "% Completing";
                }

                progressbar.Value += 20;
            }
            else
            {
                timer1.Stop();
                this.Hide();

                if (VPriv == "0")
                {
                    frm_super_admin superAdminFormA = new frm_super_admin(this);
                    superAdminFormA.aaid_supad = UNAME;

                    adminPage superAdminFormU = new adminPage(this);
                    superAdminFormU.aaid_supur = UNAME;
                    superAdminFormU.Show();
                }
                else if (VPriv == "1")
                {
                    frm_admin adminForm_ = new frm_admin(this);
                    adminForm_.aaid = AId;
                    adminForm_.aaname = UNAME;
                    adminForm_.Show();
                }
                else if (VPriv == "2")
                {
                    frm_user userForm = new frm_user(this);
                    userForm.Show();
                    userForm.uuu_ = UNAME;
                    userForm.fff_ = FUUU;
                    userForm.lll_ = LUUU;
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
