﻿namespace csharp_exercise_login_2
{
    partial class frm_admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_admin));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            label3 = new Label();
            panel4 = new Panel();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            button2 = new Button();
            panel2 = new Panel();
            cbostatus = new ComboBox();
            panel3 = new Panel();
            btncancel = new Button();
            txtpassword = new TextBox();
            addlabel = new Label();
            txtln = new TextBox();
            btninsert = new Button();
            txtfn = new TextBox();
            txtusername = new TextBox();
            tabPage2 = new TabPage();
            pictureBox2 = new PictureBox();
            txtsearch = new TextBox();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            dgusers = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            pictureBox3 = new PictureBox();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgusers).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Yu Gothic UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(105, 198);
            label3.Name = "label3";
            label3.Size = new Size(83, 23);
            label3.TabIndex = 13;
            label3.Text = "Admin_01";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            label3.Click += label3_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.White;
            panel4.Location = new Point(34, 243);
            panel4.Name = "panel4";
            panel4.Size = new Size(250, 1);
            panel4.TabIndex = 9;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(83, 44);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(139, 143);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateBlue;
            panel1.Controls.Add(label3);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(button2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4);
            panel1.Name = "panel1";
            panel1.Size = new Size(312, 806);
            panel1.TabIndex = 15;
            // 
            // button2
            // 
            button2.BackColor = Color.Transparent;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Image = (Image)resources.GetObject("button2.Image");
            button2.ImageAlign = ContentAlignment.MiddleLeft;
            button2.Location = new Point(0, 739);
            button2.Margin = new Padding(4);
            button2.Name = "button2";
            button2.Padding = new Padding(25, 0, 0, 0);
            button2.Size = new Size(312, 46);
            button2.TabIndex = 5;
            button2.Text = "        Logout";
            button2.TextAlign = ContentAlignment.MiddleLeft;
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(cbostatus);
            panel2.Controls.Add(panel3);
            panel2.Controls.Add(btncancel);
            panel2.Controls.Add(txtpassword);
            panel2.Controls.Add(addlabel);
            panel2.Controls.Add(txtln);
            panel2.Controls.Add(btninsert);
            panel2.Controls.Add(txtfn);
            panel2.Controls.Add(txtusername);
            panel2.Location = new Point(335, 25);
            panel2.Name = "panel2";
            panel2.Size = new Size(514, 591);
            panel2.TabIndex = 10;
            // 
            // cbostatus
            // 
            cbostatus.BackColor = Color.Snow;
            cbostatus.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cbostatus.ForeColor = Color.Gray;
            cbostatus.FormattingEnabled = true;
            cbostatus.Items.AddRange(new object[] { "Active", "Inactive" });
            cbostatus.Location = new Point(108, 424);
            cbostatus.Name = "cbostatus";
            cbostatus.Size = new Size(311, 31);
            cbostatus.TabIndex = 28;
            cbostatus.Text = " Status";
            // 
            // panel3
            // 
            panel3.BackColor = Color.MediumSlateBlue;
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(514, 38);
            panel3.TabIndex = 18;
            // 
            // btncancel
            // 
            btncancel.BackColor = Color.White;
            btncancel.Location = new Point(264, 512);
            btncancel.Margin = new Padding(4);
            btncancel.Name = "btncancel";
            btncancel.Size = new Size(94, 41);
            btncancel.TabIndex = 27;
            btncancel.Text = "Cancel";
            btncancel.UseVisualStyleBackColor = false;
            btncancel.Click += btncancel_Click;
            // 
            // txtpassword
            // 
            txtpassword.BackColor = Color.Snow;
            txtpassword.Font = new Font("Yu Gothic UI", 10.2F);
            txtpassword.Location = new Point(108, 358);
            txtpassword.Margin = new Padding(4);
            txtpassword.Name = "txtpassword";
            txtpassword.PlaceholderText = " Password";
            txtpassword.Size = new Size(311, 30);
            txtpassword.TabIndex = 25;
            // 
            // addlabel
            // 
            addlabel.AutoSize = true;
            addlabel.Location = new Point(188, 83);
            addlabel.Name = "addlabel";
            addlabel.Size = new Size(130, 23);
            addlabel.TabIndex = 23;
            addlabel.Text = "ADD ACCOUNT";
            // 
            // txtln
            // 
            txtln.BackColor = Color.Snow;
            txtln.Font = new Font("Yu Gothic UI", 10.2F);
            txtln.Location = new Point(108, 227);
            txtln.Margin = new Padding(4);
            txtln.Name = "txtln";
            txtln.PlaceholderText = " Last name";
            txtln.Size = new Size(311, 30);
            txtln.TabIndex = 22;
            // 
            // btninsert
            // 
            btninsert.BackColor = Color.White;
            btninsert.Location = new Point(366, 512);
            btninsert.Margin = new Padding(4);
            btninsert.Name = "btninsert";
            btninsert.Size = new Size(94, 41);
            btninsert.TabIndex = 26;
            btninsert.Text = "Insert";
            btninsert.UseVisualStyleBackColor = false;
            btninsert.Click += btninsert_Click;
            // 
            // txtfn
            // 
            txtfn.BackColor = Color.Snow;
            txtfn.Font = new Font("Yu Gothic UI", 10.2F);
            txtfn.Location = new Point(108, 158);
            txtfn.Margin = new Padding(4);
            txtfn.Name = "txtfn";
            txtfn.PlaceholderText = " First name";
            txtfn.Size = new Size(311, 30);
            txtfn.TabIndex = 21;
            // 
            // txtusername
            // 
            txtusername.BackColor = Color.Snow;
            txtusername.Font = new Font("Yu Gothic UI", 10.2F);
            txtusername.Location = new Point(108, 294);
            txtusername.Margin = new Padding(4);
            txtusername.Name = "txtusername";
            txtusername.PlaceholderText = " Username";
            txtusername.Size = new Size(311, 30);
            txtusername.TabIndex = 24;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(panel2);
            tabPage2.Location = new Point(4, 32);
            tabPage2.Margin = new Padding(4);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(4);
            tabPage2.Size = new Size(1091, 654);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "   Add Records    ";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(709, 41);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(28, 28);
            pictureBox2.TabIndex = 14;
            pictureBox2.TabStop = false;
            // 
            // txtsearch
            // 
            txtsearch.Font = new Font("Yu Gothic UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtsearch.Location = new Point(743, 38);
            txtsearch.Margin = new Padding(4);
            txtsearch.Name = "txtsearch";
            txtsearch.PlaceholderText = " Search";
            txtsearch.Size = new Size(315, 31);
            txtsearch.TabIndex = 3;
            txtsearch.TextChanged += txtsearch_TextChanged;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tabControl1.Location = new Point(348, 103);
            tabControl1.Margin = new Padding(4);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1099, 690);
            tabControl1.TabIndex = 14;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(dgusers);
            tabPage1.Controls.Add(pictureBox2);
            tabPage1.Controls.Add(txtsearch);
            tabPage1.Location = new Point(4, 32);
            tabPage1.Margin = new Padding(4);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(4);
            tabPage1.Size = new Size(1091, 654);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "  Admin Accounts  ";
            tabPage1.UseVisualStyleBackColor = true;
            tabPage1.Click += tabPage1_Click;
            // 
            // dgusers
            // 
            dgusers.AllowUserToAddRows = false;
            dgusers.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = SystemColors.InactiveBorder;
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = Color.DodgerBlue;
            dataGridViewCellStyle1.SelectionForeColor = Color.White;
            dgusers.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dgusers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgusers.BackgroundColor = Color.White;
            dgusers.CellBorderStyle = DataGridViewCellBorderStyle.None;
            dgusers.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.Linen;
            dataGridViewCellStyle2.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = Color.Linen;
            dataGridViewCellStyle2.SelectionForeColor = Color.Black;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgusers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgusers.ColumnHeadersHeight = 40;
            dgusers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgusers.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5, Column6 });
            dgusers.EnableHeadersVisualStyles = false;
            dgusers.GridColor = Color.White;
            dgusers.Location = new Point(36, 100);
            dgusers.Margin = new Padding(4);
            dgusers.Name = "dgusers";
            dgusers.ReadOnly = true;
            dgusers.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = SystemColors.InactiveBorder;
            dataGridViewCellStyle3.Font = new Font("Yu Gothic UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dgusers.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dgusers.RowHeadersWidth = 25;
            dgusers.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dgusers.ScrollBars = ScrollBars.Vertical;
            dgusers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgusers.Size = new Size(1022, 522);
            dgusers.TabIndex = 15;
            dgusers.CellContentClick += dgusers_CellContentClick;
            dgusers.CellDoubleClick += dgusers_CellDoubleClick;
            // 
            // Column1
            // 
            Column1.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column1.HeaderText = "No";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            Column1.Width = 60;
            // 
            // Column2
            // 
            Column2.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Column2.HeaderText = "First Name";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            // 
            // Column3
            // 
            Column3.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Column3.HeaderText = "Last Name";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            // 
            // Column4
            // 
            Column4.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Column4.HeaderText = "Username";
            Column4.MinimumWidth = 6;
            Column4.Name = "Column4";
            Column4.ReadOnly = true;
            // 
            // Column5
            // 
            Column5.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Column5.HeaderText = "Password";
            Column5.MinimumWidth = 6;
            Column5.Name = "Column5";
            Column5.ReadOnly = true;
            // 
            // Column6
            // 
            Column6.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column6.HeaderText = "Status";
            Column6.MinimumWidth = 6;
            Column6.Name = "Column6";
            Column6.ReadOnly = true;
            Column6.Width = 84;
            // 
            // pictureBox3
            // 
            pictureBox3.BackgroundImage = (Image)resources.GetObject("pictureBox3.BackgroundImage");
            pictureBox3.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox3.Location = new Point(1419, 12);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(40, 38);
            pictureBox3.TabIndex = 18;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Yu Gothic UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Image = (Image)resources.GetObject("label2.Image");
            label2.ImageAlign = ContentAlignment.BottomLeft;
            label2.Location = new Point(346, 40);
            label2.Name = "label2";
            label2.Size = new Size(492, 41);
            label2.TabIndex = 19;
            label2.Text = "    USER ACCOUNT MANAGEMENT";
            // 
            // frm_admin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1473, 806);
            Controls.Add(label2);
            Controls.Add(pictureBox3);
            Controls.Add(panel1);
            Controls.Add(tabControl1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frm_admin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "    Admin Page";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgusers).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label3;
        private Panel panel4;
        private PictureBox pictureBox1;
        private Panel panel1;
        private Button button2;
        private Panel panel2;
        private Panel panel3;
        private TabPage tabPage2;
        private PictureBox pictureBox2;
        private TextBox txtsearch;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private PictureBox pictureBox3;
        private DataGridView dgusers;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private ComboBox cbostatus;
        private Button btncancel;
        private TextBox txtpassword;
        private Label addlabel;
        private TextBox txtln;
        private Button btninsert;
        private TextBox txtfn;
        private TextBox txtusername;
        private Label label2;
    }
}